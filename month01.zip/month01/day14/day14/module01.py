"""
    模块1
"""


def func01():
    print("module01 -- func01")


def func02():
    print("module01 -- func02")


class MyCalss:
    def func03(self):
        print("module01 -- MyCalss -- func02")
