def func03():
    print("p2 - m3 - func03")