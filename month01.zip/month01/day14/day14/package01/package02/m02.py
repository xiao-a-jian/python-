def func02():
    print("p2 - m2 - func02")