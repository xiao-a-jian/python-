def func01():
    print("p1 - m1 - func01")