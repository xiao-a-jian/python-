"""

"""
# import usl
#
# view = usl.EpidemicInformationView()
# view.main()
from usl import EpidemicInformationView

view = EpidemicInformationView()
view.main()