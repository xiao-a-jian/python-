"""
    模块2
"""


def func01():
    print("module02 -- func01")


def func02():
    print("module02 -- func02")


class MyCalss:
    def func03(self):
        print("module02 -- MyCalss -- func02")
