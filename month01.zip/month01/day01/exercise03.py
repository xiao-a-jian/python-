"""
    汇率转换器
"""

# 1. 获取数据
usd = float(input("请输入美元："))

# 2. 逻辑处理
result = usd * 7.0321

# 3. 显示结果
print(str(usd) + "美元=" + str(result) + "人民币")

# 抄

# usd = float(input("请输入美元："))
# result = usd * 7.0321
# print(str(usd) + "美元=" + str(result) + "人民币")
# usd = float(input("请输入美元："))
# result = usd * 7.0321
# print(str(usd) + "美元=" + str(result) + "人民币")
# usd = float(input("请输入美元："))
# result = usd * 7.0321
# print(str(usd) + "美元=" + str(result) + "人民币")
