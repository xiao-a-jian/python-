from skill_system.skill_manager import SkillManager

manager = SkillManager()
manager.func01()