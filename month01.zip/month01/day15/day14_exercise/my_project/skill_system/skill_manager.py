from skill_system.skill_deployer import SkillDeployer


class SkillManager:
    def func01(self):
        print("SkillManager -- func01")


SkillDeployer().func02()