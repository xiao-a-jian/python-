class ListHelper:
    @classmethod
    def func03(cls):
        print("ListHelper - func03")
