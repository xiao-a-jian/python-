# 练习:判断句子成分
subject = input("请输入I kiss you.的主语：")
predicate = input("请输入I kiss you.的谓语：")
object = input("请输入I kiss you.的宾语：")

print("您输入的是：")
print("主语：" + subject + ",谓语:" + predicate + "宾语:" + object)

# subject = input("请输入We are students.的主语：")
# predicate = input("请输入We are students.的谓语：")
# object = input("请输入We are students.的宾语：")
# print("您输入的是：")
# print("主语：" + subject + ",谓语：" + predicate + ",宾语：" + object)
