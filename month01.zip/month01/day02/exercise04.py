# 练习: 1）从下列代码中提取变量
#      2）根据下列格式输出信息
commodity_name = "麦克风"
commodity_price = 1299.0
commodity_desciption = "魅声 T9-V5 专业录音棚级电容麦克风蓝牙伴奏外置声卡套装电脑手机直播主播设备"
commodity_review_count = 700
store_name = "麦克风旗舰店"

print(commodity_name)
print("￥" + str(commodity_price))
print(commodity_desciption)
print(str(commodity_review_count) + "+条评价")
print(store_name)
