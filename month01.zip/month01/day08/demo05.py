"""
    函数设计思想
    小而精
    练习:exercise08~13
"""


# 定义函数,两个整数相加的功能
# def add():
#     # 1. 获取数据
#     number_one = int(input("请输入第一个数字："))
#     number_two = int(input("请输入第二个数字："))
#     # 2. 逻辑处理
#     result = number_one + number_two
#     # 3. 显示结果
#     print("结果是:%d" % result)

# add()

def add(number_one, number_two):
    # 2. 逻辑处理
    return number_one + number_two

print(add(10, 20))
