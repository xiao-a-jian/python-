"""
    5. 根据内存图写出两个变量交换的代码
"""
# 左手杯子  右手鼠标
name01 = "金海"
name02 = "徐天"
# 利用桌子
# 变量交换算法
# temp = name01
# name01 = name02
# name02 = temp

# python 变量交换
name01, name02 = name02, name01

print(name01)
print(name02)
