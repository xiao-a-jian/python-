# 练习1：在终端中显示0 1 2 3 4 5 6 7 8
# 练习2：在终端中显示3 4 5 6 7 8 9 10
# 练习3：在终端中显示2 4 6 8 10 12
# 练习4：在终端中显示8 7 6 5 4 3
# 练习5：在终端中显示-1 -2 -3 -4 -5 -6
count = -1
while count < 8:
    count += 1
    print(count)

count = 2
while count < 10:
    count += 1
    print(count)

count = 0
while count < 12:
    count += 2
    print(count)

count = 9
while count > 3:
    count -= 1
    print(count)

count = 0
while count > -6:
    count -= 1
    print(count)