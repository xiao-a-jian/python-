"""
    程序入口
"""
from usl import HouseManagerView

if __name__ == "__main__":
    view = HouseManagerView()
    view.main()
